from django.apps import AppConfig


class SetupConfig(AppConfig):
    name = 'setup'
