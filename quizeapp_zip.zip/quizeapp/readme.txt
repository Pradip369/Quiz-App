1) Install Python : https://www.python.org/ftp/python/3.9.0/python-3.9.0-amd64.exe
2) Update PIP : Update pip version python -m pip install --upgrade pip
3) Install all packeges : cd to the directory where requirements.txt is located then run this command --> pip install -r requirements.txt